#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "release-2.32.62-0-g0846ba2 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "release-2.32.62-0-g0846ba2"
#endif
#define SDL_REVISION_NUMBER 0
